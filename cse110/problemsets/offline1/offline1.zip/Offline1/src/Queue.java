public class Queue {
    int queue[];
    int front;
    int rear;
    int size;

    public Queue(int size){
        this.size = size;
        this.queue = new int[size];
        this.front = -1;
        this.rear = 0;
    }
    
    public void enqueue(int x){
        
    }
	
    public void dequeue(){
        
    }
	
	public int peek(){
        
    }
	
	public void clear(){
        
    }
	
	public boolean isFull(){
		
	}
	
    public boolean isEmpty(){
        
    }
	
	public String toString(){
        
    }
	
    public static void main(String[] args) {
        
    }
}
