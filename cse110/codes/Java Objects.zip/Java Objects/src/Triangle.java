public class Triangle {
    Point p1, p2, p3;

    public Triangle(double x1, double y1, double x2, double y2, double x3, double y3){
        p1 = new Point(x1, y1);
        p2 = new Point(x2, y2);
        p3 = new Point(x3, y3);
    }

    public Triangle(Point p1, Point p2, Point p3){
        this.p1 = new Point(p1.getX(), p1.getY());
        this.p2 = new Point(p2.getX(), p2.getY());
        this.p3 = new Point(p3.getX(), p3.getY());
    }

    public boolean isEquilateral(){
        double d1 = p1.distance(p2);
        double d2 = p2.distance(p3);
        double d3 = p3.distance(p1);
        if (d1 == d2 && d2 == d3 && d3 == d1) return true;
        return false;
    }
    public String toString(){
        return "p1: " + p1.toString() + " p2: " + p2.toString() + " p3: " + p3.toString();
    }

    public Point getP1(){
        return p1;
    }

    public void setP1(Point p1){
        this.p1.setX(p1.getX());
        this.p1.setY(p1.getY());
    }

}
