public class TestTriangle {
    public static void main(String[] args) {
        Triangle t1 = new Triangle(10, 0,20, 0, 10, 10);
        System.out.println(t1.isEquilateral());

        Point p1 = new Point(10, 0);
        Point p2 = new Point(20, 0);
        Point p3 = new Point(10, 10);
        Triangle t2 = new Triangle(p1, p2, p3);
        Point p4 = new Point(40, 5);
        t2.setP1(p4);
        System.out.println(t2);

    }
}
