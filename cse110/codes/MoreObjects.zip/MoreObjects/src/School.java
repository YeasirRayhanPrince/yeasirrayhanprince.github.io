public class School {
    public Person [] listPerson;
    public int capacity;
    public int top = 0;

    public School(int capacity){
        this.capacity = capacity;
        listPerson = new Person[capacity];
    }

    public void addPerson(Person p){
        listPerson[top] = p;
        top++;
    }

    public void addPerson(Person[] p){
        for(int i=0; i < p.length; i++){
            listPerson[top] = p[i];
            top++;
        }
    }

    public String toString(){
        String tem = "";
        for(int i=0; i < top; i++){
            tem += listPerson[i].getName();
            tem += ", ";
        }
        return tem;
    }
}
