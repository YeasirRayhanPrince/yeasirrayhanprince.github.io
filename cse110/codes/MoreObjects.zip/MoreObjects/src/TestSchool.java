public class TestSchool {
    public static void main(String[] args) {
        School s = new School(40);
        Person p1 = new Person("P1", 11);
        Person p2 = new Person("P2", 10);
        Person p3 = new Person("P3", 11);

        Person [] p4 = new Person[2];
        Person a1 = new Person("A1", 6);
        Person a2 = new Person("A2", 10);
        p4[0] = a1; p4[1] = a2;

        /*s.listPerson[0] = p1;
        s.listPerson[1] = p2;
        s.listPerson[2] = p3;*/
        s.addPerson(p1);
        s.addPerson(p2);
        s.addPerson(p3);

        // s.listPerson[2] == An object of class Person
        System.out.println(s.listPerson[2].getName());
        System.out.println(s.listPerson[2].getAge());

        boolean ans = s.listPerson[0].olderThan(s.listPerson[2]);
        System.out.println(ans);

        System.out.println(s);

        s.addPerson(p4);
        System.out.println(s);

    }
}
