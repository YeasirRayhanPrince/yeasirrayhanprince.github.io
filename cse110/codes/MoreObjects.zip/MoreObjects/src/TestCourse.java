public class TestCourse {
    public static void main(String[] args) {
        Course c1 = new Course();

        Person p1 = new Person("P1", 10);
        Person p2 = new Person("P2", 11);
        Person p3 = new Person("P3", 9);
        Person p4 = new Person("P4", 9);

        c1.addStudent(p1);
        c1.addStudent(p2);

        Person[] pArray = new Person[2];
        pArray[0] = p3;
        pArray[1] = p4;

        c1.addStudent(pArray);

        System.out.println(c1);
        Person p5 = new Person("P5", 10);
        c1.addStudent(p5);

        System.out.println(c1);


    }
}

