public class Course {
    Person[] students;
    String courseID;
    int capacity;
    int top = 0;

    public Course(){
        courseID = "CSE110";
        capacity = 30;
        students = new Person[capacity];
    }

    public void addStudent(Person p){
        students[top] = p;
        top++;
    }

    public void addStudent(Person[] p){
        for(int i = 0; i < p.length; i++){
            students[top] = p[i];
            top++;
        }
    }

    public String toString(){
        String tem="";
        for(int i=0; i < top; i++){
            tem += students[i].getName() + " ";
        }
        return tem;

    }
}
