public class TestPerson {
    public static void  main(String[] args){
        Person bob = new Person("Bob", 10);
        Person brian = new Person("Brian", 30, 1.6, 60);

        //bob.age will throw an error as age is private for class Person

        System.out.println(bob);
        System.out.println(brian);

        bob.becomeOlder();
        System.out.println(bob.getAge());

        bob.becomeOlder(20);
        System.out.println(bob.getAge());

        boolean sameWeight = bob.hasSameWeight(brian);
        System.out.println("Does bob have the same weight as brian? : " + sameWeight);

        Person clonePerson = bob.clonePerson();
        System.out.println(clonePerson);

    }
}
