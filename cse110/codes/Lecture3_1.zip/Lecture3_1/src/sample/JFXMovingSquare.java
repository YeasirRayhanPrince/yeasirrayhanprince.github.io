package sample;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class JFXMovingSquare extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
		Group root = new Group();
		Scene scene = new Scene(root, 300, 300);

		Rectangle r = new Rectangle(100, 100, 50, 50);
		r.setFill(Color.RED);
		root.getChildren().add(r);
		
		scene.setOnKeyTyped(event -> {
			if (event.getCharacter().equals("w")) {
				r.setY(r.getY() + 5);
			}
			else if(event.getCharacter().equals("a")){
				r.setX(r.getX() - 5);
			}
			else if(event.getCharacter().equals("d")){
				r.setX(r.getX() + 5);
			}
			else if(event.getCharacter().equals("s")){
				r.setY(r.getY() - 5);
			}
			else {
				System.out.println("You typed a ... " + event.getCharacter());
			}
		});

		primaryStage.setScene(scene);
		primaryStage.setTitle("Moving Square");
		primaryStage.show();
		System.out.println("End of start");
	}

	public static void main(String[] args) {
		System.out.println("Hi, start of program");
		launch(args);
		System.out.println("...done launching");
	}

}
