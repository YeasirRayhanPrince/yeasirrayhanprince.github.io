package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class LogInController{
    @FXML
    private TextField textField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private Label nameLabel;
    @FXML
    private Label passwordLabel;
    @FXML
    private Button loginButton;
    @FXML
    private Button resetButton;

    @FXML
    void loginAction(ActionEvent event) {
        String validUserName = "admin";
        String validPassword = "123";
        String userName = textField.getText();
        String password = passwordField.getText();
        if (userName.equals(validUserName) && password.equals(validPassword)) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Successful LogIn");
            alert.setHeaderText("Successful LogIn");
            alert.setContentText("You have logged in successfully");
            alert.showAndWait();
        }
        else {
            // failed login
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Incorrect Credentials");
            alert.setHeaderText("Incorrect Credentials");
            alert.setContentText("The username and password you provided is not correct.");
            alert.showAndWait();
        }
    }

    @FXML
    void resetAction(ActionEvent event) {
        textField.setText(null);
        passwordField.setText(null);
    }



}
