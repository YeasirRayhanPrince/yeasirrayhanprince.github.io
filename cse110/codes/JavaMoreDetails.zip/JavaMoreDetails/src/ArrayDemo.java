public class ArrayDemo {
    public static void main(String[] args) {
        //Initializing arrays when declared
        int [] numbers1 = {1,2,3,4,5}; //int numbers1[]

        for(int i  = 0; i <numbers1.length ; i++){
            System.out.print(numbers1[i] + " ");
        }
        System.out.println();

        //Declaring arrays and allocating memory
        int[] numbers2 = new int[5];
        for(int i  = 0; i <numbers2.length ; i++){
            numbers2[i] = i;
        }

        for(int i  = 0; i <numbers2.length ; i++){
            System.out.print(numbers2[i] + " ");
        }
        System.out.println();
    }
}
