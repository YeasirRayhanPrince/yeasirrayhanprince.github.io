package sample;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class VendingMachineController {

    public VendingMachine vendingMachine;

    @FXML
    public TableView vendingTable;

    @FXML
    public Button stockButton;

    @FXML
    public Button addButton;

    @FXML
    public Button removeButton;

    @FXML
    public TextField itemName;

    @FXML
    public TextField itemPrice;

    @FXML
    public TextField removeItem;

    private boolean init = true;

    private void initializeColumns() {
        TableColumn<VendingItem, String> name = new TableColumn<>("Name");
        name.setMinWidth(80);
        name.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<VendingItem, Double> price = new TableColumn<>("Price");
        price.setMinWidth(80);
        price.setCellValueFactory(new PropertyValueFactory<>("price"));

        TableColumn<VendingItem, String> button = new TableColumn<>("Buy");
        button.setMinWidth(80);
        button.setCellValueFactory(new PropertyValueFactory<>("button"));

        vendingTable.getColumns().addAll(name, price, button);
    }

    public void load() {
        if (init) {
            initializeColumns();
            init = false;
        }

        vendingTable.setEditable(true);
        vendingTable.setItems(vendingMachine.data);
    }

    @FXML
    void stockButtonAction(ActionEvent event) {
        load();
    }

    @FXML
    void addButtonAction(ActionEvent event) {
        String name = itemName.getText();
        Double price = Double.parseDouble(itemPrice.getText());
        vendingMachine.data.add(new VendingItem(name, price, vendingMachine));
        vendingTable.refresh();
    }

    @FXML
    void removeButtonAction(ActionEvent event) {
        int idx = Integer.parseInt(removeItem.getText());
        vendingMachine.data.remove(idx);
        vendingTable.refresh();
    }

    public void setVendingMachine(VendingMachine vendingMachine)
    {
        this.vendingMachine = vendingMachine;
    }
}
