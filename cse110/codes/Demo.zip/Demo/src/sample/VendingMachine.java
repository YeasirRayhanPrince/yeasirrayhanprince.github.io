package sample;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import java.io.IOException;

public class VendingMachine extends Application {

    private Stage stage;

    public ObservableList<VendingItem> data = FXCollections.observableArrayList(
            new VendingItem("Pepsi", 2.0, this),
            new VendingItem("CocaCola",1.0, this)
    );

    public Stage getStage() {
        return stage;
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        stage = primaryStage;
        showVendingMachine();
    }

    public void showVendingMachine() throws Exception {
        // XML Loading using FXMLLoader
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("vm.fxml"));
        Parent root = loader.load();

        // Loading the controller
        VendingMachineController controller = loader.getController();
        controller.setVendingMachine(this);

        // Set the primary stage
        stage.setTitle("Vending Machine");
        stage.setScene(new Scene(root, 800, 500));
        stage.show();
    }

    public static void main(String[] args) {
        // This will launch the JavaFX application
        launch(args);
    }
}
