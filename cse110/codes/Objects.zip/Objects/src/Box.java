// Class definition:
// [public] [class] [Name-class]{
//
// }

// Method / variable Naming mechanism:
// single word: first letter small
// multiple word: first letter of the first word: small
// first letters of other words: capital


// 1. Instance Variables
// [private: Access modifier][data type][variable name]
// 2. Method
// a. Constructor Method
// Definition:
// [public] [method name: name of the class](Arg/ No Arg){
//
// }
// For Box class Constructor Method
// public Box(){}

//1. When you are allocating memory for a reference variable
// you are actually calling constructor method
// 2. If you do not explicitly define a constructor for a class
// java by default implements a constructor
// 3. Constructor initializes the instance variable
// 4. A class can have multiple constructors

// Getter and Setter Methods
// Getter Method: returns instance variable
// Definition:
// [public][return type = instance variable data type][name:getLength](){
// return
// }

// Setter Method: Instance variable value set
// Definition
// [public] [void][name: setX](int x){
//
// }

// toString Method: returns the current state of all the instance variable
// [public] [String][name:toString](){
//
// }

// Method definition
// [public][data-return type] [name-function](Arg/ No Arg){
//
// }

public class Box {
    public int length;
    public int width;
    public int height;

    public Box(){
        this.length = 10;
        this.width = 20;
        this.height = 30;
    }

    public Box(int length, int height, int width){
        this.length = length; // instance variable = arg variable
        this.width = width;
        this.height = height;
    }

    public Box(int length, int width){
        this.length = length;
        this.width = width;
    }

    public Box(Box box){
        this.length = box.length;
        this.height = box.height;
        this.width = box.width;
    }

    public int getLength(){
        return this.length;
    }

    public int getWidth(){
        return this.width;
    }

    public int getHeight(){
        return this.height;
    }

    public void setLength(int length){
        this.length = length;
    }

    public void setWidth(int width){
        this.width = width;
    }

    public void setHeight(int height){
        this.height = height;
    }


    public boolean hasLargeHeight(Box box){
        if(this.height > box.height)
            return true;
        else
            return false;
    }

    public String toString(){
        String x = "length = " + this.length + ", width = " + this.width + ", height = " + this.height;
        return x;
    }

    public void increaseDimension(int increment){
        this.length += increment;
        this.width += increment;
        this.height += increment;
    }

    public double getVolume(){
        double volume2 = this.getLength() * this.getWidth() * this.getHeight();
        return volume2;
    }

}








