public class TestBox {
    public static void main(String[] args) {
        // 1. Declare Variable
        Box b1; // reference variable: have not allocated memory for variable b1 yet
        // 2. Allocate Memory
        b1 = new Box(); // object: have allocated memory

        // These two tasks can be done in a single line
        //Box b1 = new Box();
        System.out.println(b1.getHeight());
        System.out.println(b1.toString());
        System.out.println(b1);

        Box b2 = new Box();
        System.out.println(b2.getHeight());
        System.out.println(b1.height + b2.height);

        Box b3 = new Box(10000, 20000, 3000);
        System.out.println(b2);
        System.out.println(b2.length + " " + b2. width + " " + b2.height);

        b1.increaseDimension(10);
        System.out.println(b1);
        System.out.println(b1.hasLargeHeight(b2));
        System.out.println(b2.hasLargeHeight(b1));

        System.out.println(b1.getVolume());


    }
}
