// 1. Instance Variable
// 2. Method:
// a) Constructor: Special Method
// Constructor: Definition
// [public][class-name](Arguments / No arguments){
//
// }

// Objective of Constructor:
// 1. initialize Instance Variables
// 2. When you are creating an object of a class that is
// you are allocating memory for a reference variable you are actually calling the
// constructor
// 3. If your class does not have a single constructor only then Java
// by default creates a no-arg constructor
// 4. A class can have multiple constructors



// b. Getter Method and Setter Method
// Getter Method: Return current value of an instance variable
// Getter Method Definition:
// [public] [data-type] [method-name:] getName(){
//
// }

// Setter Method: Set the value of an instance variable to argument variable
// [public] [void] [method-name] setName(data-type){
//}

// toString Method: instance variable: value --> summary return
// [public] [String] [toString](){
//
// }
// To call a toString Method: sout(object-name)


// Normal Method: Definition
// [Access Modifier][data-type][method-name](Arguments){
//
// }

public class Person {
    private String name; // default: null
    private int age; // default: 0
    private double height;
    private double weight;

    // No-arg Constructor
    public Person(){
        this.name = "John";
        this.age = 1;
    }

    // Constructor with 2 arguments
    public Person(String name, int age){
        // instance variable = argument variable
        this.name = name;
        this.age = age;
    }

    public Person(String name, int age, double height, double weight){
        // instance variable = argument variable
        this.name = name;
        this.age = age;
        this.height = height;
        this.weight = weight;
    }

    public String getName(){
        return this.name;
    }
    public int getAge(){
        return this.age;
    }

    public void setName(String name){
        this.name = name;
    }
    public void setAge(int age){
        this.age = age;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String toString(){
        return this.name + ", " + this.age;
    }

    public void becomeOlder() {
        this.age++;;    // same as this.age = this.age + 1;
    }

    public boolean isAdult(){
        if ( this.age < 18 ) {
            return false;
        }
        return true;
    }

    public boolean olderThan(Person person) {
        if ( this.age > person.age ) return true;
        return false;
    }

    public double bodyMassIndex(){
        double heightDividedByHundred = this.height / 100.0;
        return this.weight / ( heightDividedByHundred * heightDividedByHundred );
    }
}
