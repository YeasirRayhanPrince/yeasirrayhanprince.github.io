public class StaticTest {
    private static int a = 3;
    static int b;
    int c;

    static {
        b = a * 4;
        //c = b; // Error
    }

    public int getA(){
        return this.a;
    }

    public void setA(int a){
        this.a = a;
    }

    static void f1(int x) {
        System.out.println("x = " + x); // x argument
        System.out.println("a = " + a); // a = static variable
        System.out.println("b = " + b); // b = static variable
        //System.out.println("c = " + c); // Error
    }

    int f2() {
        return a * b;
    }

    public static void main(String[] args) {
        System.out.println(StaticTest.a);
        System.out.println(StaticTest.b);
        // System.out.println(StaticTest.c); // Error: c is a non-static variable

        StaticTest.f1(84);
        //StaticTest.f2(); // Error

        StaticTest o = new StaticTest();
        System.out.println(o.c);
        o.f2();

        StaticTest ob1 = new StaticTest();
        ob1.a++;
        ob1.b *= 10;
        ob1.c++;
        System.out.println("a in ob1 = "+ ob1.a);
        System.out.println(ob1.b);
        System.out.println("c in ob1 = "+ ob1.c);

        StaticTest ob2 = new StaticTest();
        ob2.a++;
        ob2.b -= 2;
        ob2.c++;
        System.out.println("a in ob2 = "+ ob2.a);
        System.out.println(ob2.b);
        System.out.println("c in ob2 = "+ ob2.c);

        System.out.println(ob1.a);
    }
}
