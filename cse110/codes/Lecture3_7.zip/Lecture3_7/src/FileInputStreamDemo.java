import java.io.FileInputStream;
import java.io.InputStream;

class FileInputStreamDemo {
    public static void main(String args[]) throws Exception {
        InputStream f = new FileInputStream("dir/sample.txt");
        int size = f.available();
        System.out.println(size);

        int n = size / 10; // This many bytes we want to read

        for (int i = 0; i < n; i++) {
            System.out.print( (char) f.read());
        }
        System.out.println();

        System.out.println(f.available());
        byte b[] = new byte[n];
        f.read(b);
        System.out.println(new String(b, 0, n));

        size = f.available();
        System.out.println(size);
        f.skip(size / 2);
        System.out.println(f.available());

        f.read(b, n / 2, n/2 );
        System.out.println(new String(b, 0, b.length));
        System.out.println(f.available());
    }
}
