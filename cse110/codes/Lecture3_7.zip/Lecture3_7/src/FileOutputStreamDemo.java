import java.io.FileOutputStream;
import java.io.OutputStream;

class FileOutputStreamDemo {
    public static void main(String args[]) throws Exception {
        String source = "No Alarms\n"
                + " And\n"
                + " No Surprises.";
        byte buf[] = source.getBytes();

        OutputStream f1 = new FileOutputStream("f1.txt");
        for (int i = 0; i < buf.length; i += 1) {
            f1.write(buf[i]);
        }
        f1.close();

        OutputStream f2 = new FileOutputStream("f2.txt");
        f2.write(buf);
        f2.close();

        OutputStream f3 = new FileOutputStream("f3.txt");
        f3.write(buf, buf.length - buf.length / 4, buf.length / 4);
        f2.close();
    }
}