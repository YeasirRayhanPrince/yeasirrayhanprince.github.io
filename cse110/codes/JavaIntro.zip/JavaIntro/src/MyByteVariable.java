public class MyByteVariable {
    public static void main(String[] args){
        byte variable = 127;
        //byte variable = 200 shows error
        System.out.println(variable);
    }
}
