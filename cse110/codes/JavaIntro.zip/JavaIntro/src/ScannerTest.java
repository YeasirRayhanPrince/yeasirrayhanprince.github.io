import java.util.Scanner;
public class ScannerTest {
    public static void main(String[] args) {
        Scanner scn1=new Scanner(System.in);
        int x = scn1.nextInt();
        double y = scn1.nextDouble();
        System.out.println("x = " + x);
        System.out.println("y = " + y);
        /*while(scn2.hasNextLine())
        {
            System.out.println(scn2.nextLine());
        }*/
        while(scn1.hasNextInt())
        {
            System.out.println(scn1.nextInt());
        }

    }
}
