public class Box {
    int l, w, h;


    public Box(int l, int w, int h) {
        this.l = l;
        this.w = w;
        this.h = h;
    }

    public static void main(String[] args) {
        Box box; //declares box as a reference ---- to an object of type Box.
        box = new Box(10, 20, 30); //allocates an object and assigns ------- reference to it to box
        System.out.println(box.h+" "+box.w+" "+box.l);
    }

}

