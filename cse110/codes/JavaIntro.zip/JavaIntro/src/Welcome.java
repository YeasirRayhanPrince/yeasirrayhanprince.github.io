public class Welcome {
    public static void main(String[] args) {
        System.out.println("Hello Java");
        System.out.printf("Hello ");
        System.out.printf("Java");
        System.out.println();
    } // end method main
} // end class Welcome ‐ NOTE: no semicolon is required here
