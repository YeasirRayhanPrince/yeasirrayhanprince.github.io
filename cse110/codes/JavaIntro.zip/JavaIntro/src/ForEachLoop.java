public class ForEachLoop {
    public static void main(String[] args) {
        int[] numbers3 = new int[5];
        for(int x: numbers3){
            System.out.print(x);
        }
        System.out.println();
        double[] numbers1 = new double[5];
        for(double x: numbers1){
            System.out.print(x);
        }
        System.out.println();
    }
}
