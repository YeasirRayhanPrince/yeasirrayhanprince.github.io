package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ShowImage extends Application {
    Stage stage;

    @Override
    public void start(Stage primaryStage) throws Exception {
        stage = primaryStage;
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("imageview.fxml"));
        Parent root = loader.load();

        // Loading the controller
        ImageViewController imageViewController = loader.getController();
        imageViewController.init();
        imageViewController.setShowImage(this);

        primaryStage.setTitle("Show Image");
        primaryStage.setScene(new Scene(root, 600, 600));
        primaryStage.show();

        stage.getScene().setOnKeyTyped(event -> {
            if (event.getCharacter().equals("w")) {
                imageViewController.imageView.setY(imageViewController.imageView.getY() + 5);
            }
            else if(event.getCharacter().equals("a")){
                imageViewController.imageView.setX(imageViewController.imageView.getX() - 5);
            }
            else if(event.getCharacter().equals("d")){
                imageViewController.imageView.setX(imageViewController.imageView.getX() + 5);
            }
            else if(event.getCharacter().equals("s")){
                imageViewController.imageView.setY(imageViewController.imageView.getY() - 5);
            }
            else {
                System.out.println("You typed a ... " + event.getCharacter());
            }
        });
    }





}
