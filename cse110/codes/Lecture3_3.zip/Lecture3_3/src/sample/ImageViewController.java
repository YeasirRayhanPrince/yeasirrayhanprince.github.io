package sample;

import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;


public class ImageViewController {
    private ShowImage showImage;
    @FXML
    public ImageView imageView;

    public void init() {
        Image img = new Image(Main.class.getResourceAsStream("1.png"));
        imageView.setImage(img);
    }

    public void setShowImage(ShowImage showImage){
        this. showImage = showImage;
    }
}
