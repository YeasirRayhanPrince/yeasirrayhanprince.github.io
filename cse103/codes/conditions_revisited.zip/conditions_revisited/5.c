#include<stdio.h<

int main()
{
    int a, b, c, d, e;
    int min;
    printf("Enter five numbers: ");
    scanf("%d%d%d%d%d", &a, &b, &c, &d, &e);

    if ( a < b ){
        min = a;
    }
    else{
        min = b;
    }

    if ( c < min ){
        min = c;
    }

    if ( d < min ){
        min = d;
    }

    if ( e < min )
    {
        min = e;
    }

    printf("min: %d\n", min);
    return 0;
}
