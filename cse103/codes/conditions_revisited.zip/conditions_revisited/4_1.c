#include<stdio.h>

int main()
{
    int a, b, c;
    int min;
    printf("Enter three numbers: ");
    scanf("%d%d%d", &a, &b, &c);

    if ( a <= b && a <= c)
    {
        min = a;
    }
    if ( b <= a && b <= c)
    {
        min = b;
    }
    if ( c <= a && c <= b)
    {
        min = c;
    }
    printf("min: %d\n", min);
    return 0;
}
