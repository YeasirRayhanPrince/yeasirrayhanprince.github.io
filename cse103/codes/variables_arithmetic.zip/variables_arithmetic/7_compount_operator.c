#include<stdio.h>

int main() {
    int a = 10;
    int b = 2;
    a += b; // a = a + b
    a -= b; // a = a - b
    a *= b; // a = a * b
    a /= b; // a = a / b;
    a %= b; // a = a % b
    return 0;
}
