#include<stdio.h>
int main(){
    int a = 2;
	printf("a = %d\n", a);
    float b = 2.3;
    printf("b = %f\n", b);

	double c = 1234567.89123;
	printf("c = %lf\n", c);

	char d = 'A';
	printf("d = %c\n", d);

	a = 5;
    printf("a = %d\n", a);
	return 0;

}
