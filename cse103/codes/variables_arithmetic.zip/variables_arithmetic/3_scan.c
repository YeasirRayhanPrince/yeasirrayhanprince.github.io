#include<stdio.h>
int main() {
	int a;
    scanf("%d", &a);

	float b;
    scanf("%f", &b);

	double c;
    scanf("%lf", &c);

	char d;
    scanf(" %c", &d); // Be careful about the space before %

	printf("a = %d\n", a);
	printf("b = %f\n", b);
	printf("c = %lf\n", c);
    printf("d = %c\n", d);
	return 0;
}
