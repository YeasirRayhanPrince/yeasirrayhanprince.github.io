#include<stdio.h>
int main() {
    double a, b, c;
    a = 2.3;
    b = 3.1;
    c = a % b;
    printf("%d", c);
	return 0;
}
