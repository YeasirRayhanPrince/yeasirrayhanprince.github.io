#include<stdio.h>
// BASICS OF POINTER
int main() {

    int i = 10, j = 20;
    int *p1 = NULL, *p2 = NULL;
    printf("%d %d\n", &i, &j);
    printf("%d %d\n", i, j);
    printf("%d %d\n", p1, p2);
    printf("\n");

    p1 = &i;
    printf("%d %d\n", i, j);
    printf("%d %d\n", p1, p2);
    printf("\n");

    p2 = p1;
    printf("%d %d\n", i, j);
    printf("%d %d\n", p1, p2);
    printf("\n");

    p1 = &j;
    printf("%d %d\n", i, j);
    printf("%d %d\n", p1, p2);
    printf("\n");

    *p1 = 100;
    printf("%d %d\n", i, j);
    printf("%d %d\n", p1, p2);
    printf("\n");

    *p2 = *p1;
    printf("%d %d\n", i, j);
    printf("%d %d\n", p1, p2);
    printf("\n");

    p2 = &p1;
    printf("%d %d\n", i, j);
    printf("%d %d\n", p1, p2);
    printf("\n");


    *p2 = 10;
    printf("%d %d\n", i, j);
    printf("%d %d\n", p1, p2);
    printf("\n");

}
