#include<stdio.h>
//1D ARRAY INPUT AND OUTPUT USING POINTER
int main() {
    int N;
    scanf("%d", &N);
    int a[N], i;
    int *p = a;
    for(i = 0; i< N; i++)
        scanf("%d", (p+i));

    for ( i = 0; i < N; i++)
        printf("%d ", *(p+i));


    return 0;
}
