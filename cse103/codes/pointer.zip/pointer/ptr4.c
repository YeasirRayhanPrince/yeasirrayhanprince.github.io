#include<stdio.h>
//2D ARRAY INPUT AND OUTPUT USING POINTER
int main() {
    int R, C;
    scanf("%d %d", &R, &C);
    int x[R][C];
    int *p = x;
    int i, j;
    for(i = 0; i < R; i++) {
        for( j = 0; j < C; j++){
            scanf("%d", (p + i*C + j));
        }
    }

    for(i = 0; i < R; i++) {
        for( j = 0; j < C; j++){
            printf("%d ", *(p + i*C + j));
        }
        printf("\n");
    }

    return 0;
}
