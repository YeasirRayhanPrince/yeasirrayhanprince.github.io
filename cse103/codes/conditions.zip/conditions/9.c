#include <stdio.h>
int main()
{
    int a, b, c;
    int min;
    printf("Enter three numbers: ");
    scanf("%d%d%d", &a, &b, &c);
    if(a < b)
    {
        if(a < c)
        {
            min = a;
        }
        else
        {
            min = c;
        }
    }
    else
    {
        if (b < c)
        {
            min = b;
        }
        else
        {
            min = c;
        }
    }
    printf("Max: %d\n", max);
    return 0;
}
