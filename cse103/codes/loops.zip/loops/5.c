#include<stdio.h>

// 1 - x + x^2 - x^3 + x^4 - ..... + x^n
int main() {
    int counter = 1, x, n, sum, term, sign;
    printf("Enter x and n: ");
    scanf("%d%d", &x, &n);
    sum = 0; // initial sum
    term = 1;
    sign = 1; // initial sign
    while(counter <= n){
        sum = sum + sign * term;
        term = term * x;
        sign = sign * -1;
        counter++;
    }
    printf("Result: %d\n", sum);
    return 0;
}
