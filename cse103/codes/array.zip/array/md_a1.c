#include<stdio.h>

int main() {
    int a[4][5] = {{1, 2, 3, 4, 5},
                   {6, 7, 8, 9, 10},
                   {11, 12, 13, 14, 15},
                   {16, 17, 18, 19, 20}};

    int b[4][5] = {{1, 2, 3, 4, 5},
                   {6, 7, 8, 9, 10}};

    int c[4][5] = {{1, 2, 3, 4, 5},
                   {6, 7},
                   {11, 12, 13, 14, 15},
                   {16, 17, 18, 19, 20}};
    int d[4][5] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20};
    int i, j;
    for ( i = 0; i < 4; i++ ) // iterate over rows
    {
        for (  j = 0; j < 5; j++ ) // iterate over columns
        {
            printf("%d ", a[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    printf("\n");
    printf("\n");
    for ( i = 0; i < 4; i++ ) // iterate over rows
    {
        for (  j = 0; j < 5; j++ ) // iterate over columns
        {
            printf("%d ", b[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    printf("\n");
    printf("\n");
    for ( i = 0; i < 4; i++ ) // iterate over rows
    {
        for (  j = 0; j < 5; j++ ) // iterate over columns
        {
            printf("%d ", c[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    printf("\n");
    printf("\n");
    for ( i = 0; i < 4; i++ ) // iterate over rows
    {
        for (  j = 0; j < 5; j++ ) // iterate over columns
        {
            printf("%d ", d[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    printf("\n");
    printf("\n");
    return 0;
}
