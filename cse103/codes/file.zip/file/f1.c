#include <stdio.h>
int main(){
    char filename[] = "a.txt";
    FILE *inputFile = fopen( filename, "w" );

	if(inputFile == NULL){
		printf("Error- Unable to open %s\n", filename );
		exit(-1);
	}

    unsigned int account;
    double balance;
    scanf("%d %f", &account, &balance);
    while(!feof(stdin)){
        fprintf(inputFile, "%d %f\n", account, balance);
        printf("%s\n", "? ");
        scanf("%d %f", &account, &balance);
    }

	fclose(inputFile);

}
