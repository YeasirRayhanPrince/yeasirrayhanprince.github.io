#include <stdio.h>
int main(){
    char filename[] = "a.txt";
    FILE *inputFile = fopen( filename, "r" );

	if(inputFile == NULL){
		printf("Error- Unable to open %s\n", filename );
		exit(-1);
	}
    int account;
    double balance;
    while(!feof(inputFile) ){
        fscanf(inputFile, "%d %f", &account, &balance);
        printf("%d %f\n", account, balance);
    }

	fclose(inputFile);

}
