#include<stdio.h>

double average(int a[][2], int r, int c) {
    int i, j;
    int sum = 0;
    for(i = 0; i < r; i++){
        for(j = 0; j < c; j++){
            sum += a[i][j];
        }
    }
    double avg = (double)sum / (r*c);
    return avg;
}

int main() {
    int i, j, R, C;
    double z;
    printf("Enter array row: ");
    scanf("%d", &R);
    int x[R][2];
    printf("Enter array: ");
    for(i = 0; i < R; i++){
        for(j = 0; j < 2; j++){
            scanf("%d", &x[i][j]);
        }
    }
    z = average(x, R, 2);
    printf("Average: %.2f\n", z);

    return 0;
}
