#include<stdio.h>
int main() {
    int a[5], b[5], c[5];
    int i;
    for (i = 0; i < 5; i++){
        scanf("%d", &a[i]);
    }
    for (i = 0; i < 5; i++){
        scanf("%d", &b[i]);
    }
    for (i = 0; i < 5; i++){
        scanf("%d", &c[i]);
    }
    for (i = 0; i <5; i++){
        printf("%d ", a[i]);
    }
    printf("\n");
    for (i = 0; i <5; i++){
        printf("%d ", b[i]);
    }
    printf("\n");
    for (i = 0; i <5; i++){
        printf("%d ", c[i]);
    }
    printf("\n");

    int max1 = -1;
    for (i = 0; i <5; i++){
        if(a[i] > max1) max1 = a[i];
    }
    printf("%d\n", max1);

    int max2 = -1;
    for (i = 0; i <5; i++){
        if(b[i] > max2) max2 = b[i];
    }
    printf("%d\n", max2);

    int max3 = -1;
    for (i = 0; i <5; i++){
        if(c[i] > max3) max3 = c[i];
    }
    printf("%d\n", max3);

    for (i = 0; i <5; i++){
        printf("%d", a[i]);
    }
    printf("\n");
    for (i = 0; i <5; i++){
        printf("%d", b[i]);
    }
    printf("\n");
    for (i = 0; i <5; i++){
        printf("%d", c[i]);
    }
    printf("\n");
}
