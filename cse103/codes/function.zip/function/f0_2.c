#include<stdio.h>
int find_max(int a[], int n){
    int i;
    int max = -1;
    for (i = 0; i < n ; i++){
        if(a[i] > max) max = a[i];
    }
    return max;
}
void print_array(int a[], int n){
    int i;
    for (i = 0; i < n ; i++){
        printf("%d", a[i]);
    }
    printf("\n");
}

int main() {
    int a[5], b[5], c[5];
    int i;
    for (i = 0; i < 5; i++){
        scanf("%d", &a[i]);
    }
    for (i = 0; i < 5; i++){
        scanf("%d", &b[i]);
    }
    for (i = 0; i < 5; i++){
        scanf("%d", &c[i]);
    }
    print_array(a, 5);
    print_array(b, 5);
    print_array(c, 5);

    int max1 = find_max(a, 5);
    int max2 = find_max(b, 5);
    int max3 = find_max(c, 5);

    printf("%d\n", max1);
    printf("%d\n", max2);
    printf("%d\n", max3);

    print_array(a, 5);
    print_array(b, 5);
    print_array(c, 5);
}
