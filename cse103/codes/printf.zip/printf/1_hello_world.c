#include <stdio.h>
int main( )
{
    printf("Hello ");
    printf("World");
    return 0;
}
