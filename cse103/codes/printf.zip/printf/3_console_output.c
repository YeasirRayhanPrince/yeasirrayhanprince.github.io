#include <stdio.h>
int main() {
	printf("Welcome to C\n");

	//the above can be done in following way
	printf("Welcome");
	printf(" to ");
	printf(" C ");
	printf("\n");
	return 0;
}
