#include <stdio.h>
#include <math.h>
/*Finds gcd (greatest common divisor) of two numbers*/
int main() {
    int m, n;
    printf("Enter m: ");
    scanf("%d", &m);
    printf("Enter n: ");
    scanf("%d", &n);

    int gcd = 1; //initialize gcd
    int min = 999999;

    if(m < n) min = m;
    else min = n;

    int i;
    for ( i = min; i >= 2; i--) {
        if ( n % i == 0 && m % i ==0) {
            gcd = min;
            break;
        }
    }
    printf("%d", gcd);
    return 0;
}
