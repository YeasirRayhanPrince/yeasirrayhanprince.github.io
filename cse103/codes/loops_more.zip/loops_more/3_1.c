#include <stdio.h>
#include <math.h>
/*Finds lcm (least common multiple) of two numbers*/
int main() {
    int m, n;
    printf("Enter m: ");
    scanf("%d", &m);
    printf("Enter n: ");
    scanf("%d", &n);

    int max = -99999;
    if(m > n) max = m;
    else max = n;
    int lcm = max; //initialize gcd

    int i;
    for ( i = lcm; i <= m*n; i+=max) {
        if ( i % m == 0 && i % n == 0) {
            lcm = i;
            break;
        }
    }
    printf("%d", lcm);
    return 0;
}
