#include <stdio.h>
int main(){
    // Initializing strings
    char s1[] = { 'h', 'e', 'l', 'l', 'o', ' ', 'w', 'o', 'r', 'l', 'd', '\0' };
    char s2[] = "hello World";
    char s3[20] = "hello World";

    // printing strings
    puts(s1);
    printf("%s\n", s1);

    // scanning strings
    char s5[40];
    gets(s5);
    puts(s5);

    char s4[40];
    scanf("%s", &s4);
    puts(s4);

}
