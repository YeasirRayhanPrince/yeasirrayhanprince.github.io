#include <stdio.h>
int main(){
    char s[100];
    printf("Enter String: ");
    gets(s);
    char words[20][20];

    int i = 0;
    int word_count = 0;
    int j = 0;

    while(s[i] != '\0'){
        if (s[i] == ' '){
            words[word_count][j] = '\0';
            word_count++;
            j=0;
        }
        else{
            words[word_count][j] = s[i];
            j++;
        }
        i++;
    }

    for(i=0;i <= word_count;i++)
        puts(words[i]);
    return 0;
}
