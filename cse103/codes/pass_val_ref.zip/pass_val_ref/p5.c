#include<stdio.h>

void calculator(int a, int b, int c[]){
    c[0] = a + b;
    c[1] = a - b;
    c[2] = a * b;
    c[3] = a / b;
}

int main() {
    int a = 10, b = 20;
    int cal[4];
    calculator(a, b, cal);

    printf("Sum = %d\n", cal[0]);
    printf("Sub = %d\n", cal[1]);
    printf("Mul = %d\n", cal[2]);
    printf("Div = %d\n", cal[3]);
    return 0;
}
