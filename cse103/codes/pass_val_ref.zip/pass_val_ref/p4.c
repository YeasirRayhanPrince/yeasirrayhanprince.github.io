#include<stdio.h>

void shift(const int a[], int size, int num){
    int i;
    for(i = 0; i < size; i++){
        a[i] = a[i] + num;
    }
}

int main() {
    int n;
    printf("Enter Size = ");
    scanf("%d", &n);
    int x[n];
    int i;
    for(i = 0; i < n; i++){
        scanf("%d", &x[i]);
    }
    for(i = 0; i < n; i++){
        printf("%d ", x[i]);
    }
    printf("\n");

    shift(x, n, 10); // This call to function shift will generate error

    for(i = 0; i < n; i++){
        printf("%d ", x[i]);
    }
    printf("\n");
    return 0;
}
