#include<stdio.h>

double average1(int a, int b, int c){
    double average = (a + b + c) / 3;
    return average;
}

double average2(int *a, int *b, int *c){
    double average = (*a + *b + *c) / 3;
    return average;
}

double average3(int *a, int b, int *c){
    double average = (*a + b + *c) / 3;
    return average;
}

int main() {
    int a = 10, b = 20, c = 30;

    double avg1 = average1(a, b, c); //pass by value
    printf("%f\n", avg1);
    double avg2 = average2(&a, &b, &c); // pass by pointer
    printf("%f\n", avg2);
    double avg3 = average3(&a, b, &c); // pass by value & pointer both
    printf("%f\n", avg3);

    double avg4 = average1(&a, &b, &c); //pass by value
    printf("%f\n", avg4);
    double avg5 = average1(&a, b, &c); //pass by value
    printf("%f\n", avg5);

    return 0;
}
