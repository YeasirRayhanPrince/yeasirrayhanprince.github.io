#include <stdio.h>
int main()
{
    int num;
    scanf("%d", &num);

    int d1 = num / 10;
    int r1 = num % 10;
    printf("%d %d\n", d1, r1);
    int d2 = d1 / 10;
    int r2 = d1 % 10;
    printf("%d %d\n", d2, r2);
    int d3 = d2 / 10;
    int r3 = d2 % 10;
    printf("%d %d\n", d3, r3);
    int d4 = d3 / 10;
    int r4 = d3 % 10;
    printf("%d %d\n", d4, r4);

    printf("%d %d %d %d", r1, r2, r3, r4);
}
