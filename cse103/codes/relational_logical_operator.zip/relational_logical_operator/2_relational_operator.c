int main() {
    int a = 10;
    int b = -20;
    int c = 0;
    printf("%d\n", a > 0);
    printf("%d\n", b > 0);
    printf("%d\n", c >= 0);
    printf("%d\n", c <= 0);

    printf("%d\n", c == 0);
    printf("%d\n", c != 0);
    return 0;
}
