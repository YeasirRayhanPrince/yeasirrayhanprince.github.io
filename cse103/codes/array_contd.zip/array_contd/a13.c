#include<stdio.h>

int main() {
    int i, j, r, c;
    printf("Enter number of rows: ");
    scanf("%d", &r);
    printf("Enter number of columns: ");
    scanf("%d", &c);
    int a[r][c];

    printf("Enter the matrix: ");
    for ( i =0 ; i< r; i++ ) {
        for ( j = 0; j < c; j++ ) {
            scanf("%d", &a[i][j]);
        }
    }

    // sum of first diagonal
    int sum1= 0;
    for ( i =0 ; i< r; i++ ) {
        for (j = 0; j < r; j++){
            if (i == j) sum1 = sum1 + a[i][j];;
        }
    }
    printf("Sum of first diagonal = %d\n", sum1);

    // sum of second diagonal
    int sum2= 0;
    for ( i =0 ; i< r; i++ ) {
        for (j = 0; j < r; j++){
            if (i + j == r-1 ) sum2 = sum2 + a[i][j];;
        }
    }
    printf("Sum of second diagonal = %d\n", sum2);

    if (sum1 == sum2) {
        printf("Sum of diagonals are same\n");
    }
    else {
        printf("Sum of diagonals are not same\n");
    }

    return 0;
}
