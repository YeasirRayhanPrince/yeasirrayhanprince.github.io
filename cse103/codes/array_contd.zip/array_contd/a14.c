#include<stdio.h>

int main() {
    int i, j, r, c;
    printf("Enter number of rows: ");
    scanf("%d", &r);
    printf("Enter number of columns: ");
    scanf("%d", &c);
    int a[r][c];

    printf("Enter the matrix: ");
    for ( i =0 ; i< r; i++ ) {
        for ( j = 0; j < c; j++ ) {
            scanf("%d", &a[i][j]);
        }
    }

    int flag = 0;
    for ( i =0 ; i< r; i++ ) {
        for ( j = 0; j < c; j++ ) {
            if(i > j) {
                if(a[i][j] != 0) flag = 1;
            }
            if(i <= j){
                if(a[i][j] <= 0) flag = 1;
            }
        }
    }

    if (flag == 1) {
        printf("Not upper triangular matrix");
    }
    else {
        printf("upper triangular matrix\n");
    }

    return 0;
}
