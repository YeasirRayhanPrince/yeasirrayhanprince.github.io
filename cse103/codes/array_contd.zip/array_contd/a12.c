#include<stdio.h>
/*is an array monotone increasing*/
int main() {
    int i, N;
    printf("How many numbers: ");
    scanf("%d", &N);
    int a[N];
    printf("Enter the numbers: ");
    for ( i = 0; i < N; i++)
    {
        scanf("%d", &a[i]);
    }

    int flag = 0;
    for ( i = 0; i < N-1; i++)
    {
        if(a[i+1] < a[i]){
            flag = 1;
            break;
        }
    }
    if(flag == 1) printf("Not monotone increasing");
    else printf("monotone increasing");
    return 0;
}


