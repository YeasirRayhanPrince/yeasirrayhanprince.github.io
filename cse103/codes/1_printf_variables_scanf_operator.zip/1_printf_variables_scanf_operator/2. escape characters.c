#include <stdio.h>
int main( )
{
    printf("Hello World!!!\\");
    printf("Hello World!!!\t");
    printf("Hello World!!!\"");
    printf("Hello World!!!\n");
    return 0;
}




