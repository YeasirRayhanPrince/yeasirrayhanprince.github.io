int main( )
{
    printf("Welcome to C!\\");
    printf("Welcome to C!\t");
    printf("Welcome to C!\"");
    printf("Welcome to C!\n");
    return 0;
}




