int main(){
	/*
        This is a longer comment
        that extends over
        five lines
    */
    printf("Welcome to C\n");
	// This is a single line comment
	return 0;
}

