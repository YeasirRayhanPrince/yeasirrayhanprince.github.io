int main( )
{
    printf("Welcome to C!\n");
    return 0;

}


