#include<stdio.h>

int main() {
	char c;
	int i;
	float f;
	double d;
	c = 'a';
	i = 100;
	f = 12.34;
	d = 1234567.89123;
	printf("c = %c\n", c);
	printf("i = %d\n", i);
	printf("f = %f\n", f);
	printf("d = %lf\n", d);
	return 0;
}
