int main(){
    int a;
    int b;
    //int a, b;

    a = 2;
    b = 3;

    int sum;
    sum = a + b;
    printf("Sum %d", sum);
    //printf("Sum %d", a + b);
    return 0;
}
